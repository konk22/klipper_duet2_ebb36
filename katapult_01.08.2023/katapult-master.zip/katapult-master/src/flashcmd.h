#ifndef __FLASHCMD_H
#define __FLASHCMD_H

int flashcmd_is_in_transfer(void);

#endif // flashcmd.h
